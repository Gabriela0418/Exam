﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sessia1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            password_textBox.UseSystemPasswordChar = true;
        }

        private void enter_button_Click(object sender, EventArgs e)
        {
            if (login_textBox.Text == "admin" && password_textBox.Text == "admin")
            {
                Entrance entrance = new Entrance();
                entrance.ShowDialog();
                this.Close();
            }
            else
                MessageBox.Show("Указан неправельный логин или пароль");
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            login_textBox.Clear();
            password_textBox.Clear();
        }

        private void guest_button_Click(object sender, EventArgs e)
        {
            Entrance entrance = new Entrance();
            entrance.Text = "Товары";
            entrance.ShowDialog();
            this.Close();
        }
    }
}
